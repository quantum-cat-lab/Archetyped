#include "Arche.h"

int main(int argc, char* argv[]) {
    Arche app;
    app.run(argc, argv);
    return 0;
}
